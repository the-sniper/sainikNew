from django.apps import AppConfig


class ServicedetailsConfig(AppConfig):
    name = 'ServiceDetails'
