from django.apps import AppConfig


class FamilydetailsConfig(AppConfig):
    name = 'FamilyDetails'
